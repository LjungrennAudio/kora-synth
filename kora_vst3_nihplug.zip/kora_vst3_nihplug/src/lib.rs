use nih_plug::prelude::*;
use rand::Rng;
use std::sync::Arc;

/// Karplus-Strong string
#[derive(Clone)]
struct KoraString {
    buffer: Vec<f32>,
    pos: usize,
    feedback: f32,
    decay: f32,
}

impl KoraString {
    fn new(freq: f32, sample_rate: f32, decay: f32) -> Self {
        let length = (sample_rate / freq).max(2.0) as usize;
        let mut buffer = vec![0.0; length];
        let mut rng = rand::thread_rng();
        for s in &mut buffer {
            *s = rng.gen_range(-0.8..0.8);
        }
        Self {
            buffer,
            pos: 0,
            feedback: 0.985,
            decay,
        }
    }

    fn pluck(&mut self, intensity: f32) {
        let mut rng = rand::thread_rng();
        for s in &mut self.buffer {
            *s = rng.gen_range(-1.0..1.0) * intensity;
        }
        self.pos = 0;
    }

    fn get_sample(&mut self) -> f32 {
        if self.buffer.is_empty() {
            return 0.0;
        }
        let sample = self.buffer[self.pos];
        let next = (self.pos + 1) % self.buffer.len();
        let avg = (sample + self.buffer[next]) * 0.5 * self.feedback;
        self.buffer[self.pos] = avg * self.decay;
        self.pos = next;
        sample * 0.7
    }
}

const KORA_TUNING: [f32; 21] = [
    87.31, 98.00, 110.00, 116.54, 130.81, 146.83, 164.81, 174.61, 196.00,
    220.00, 233.08, 261.63, 293.66, 329.63, 349.23, 392.00, 440.00, 466.16,
    523.25, 587.33, 659.25,
];

struct KoraSynth {
    strings: Vec<KoraString>,
    sample_rate: f32,
}

impl KoraSynth {
    fn new(sample_rate: f32) -> Self {
        let strings: Vec<KoraString> = KORA_TUNING
            .iter()
            .map(|&f| KoraString::new(f, sample_rate, 0.992))
            .collect();
        Self { strings, sample_rate }
    }

    fn pluck_closest(&mut self, midi_note: u8, velocity: f32) {
        let target_freq = 440.0 * 2.0_f32.powf((midi_note as f32 - 69.0) / 12.0);
        let mut best_idx = 0;
        let mut best_diff = f32::MAX;
        for (i, &tuned) in KORA_TUNING.iter().enumerate() {
            let diff = (tuned - target_freq).abs();
            if diff < best_diff {
                best_diff = diff;
                best_idx = i;
            }
        }
        let intensity = (velocity / 127.0).clamp(0.3, 1.0);
        self.strings[best_idx].pluck(intensity);
    }

    fn get_next_sample(&mut self) -> f32 {
        let mut sum = 0.0;
        for s in &mut self.strings {
            sum += s.get_sample();
        }
        (sum * 0.045).clamp(-0.95, 0.95)
    }
}

#[derive(Default)]
struct KoraVst {
    params: Arc<KoraVstParams>,
    synth: Option<KoraSynth>,
}

#[derive(Params)]
struct KoraVstParams {
    #[id = "decay"]
    pub decay: FloatParam,
    #[id = "feedback"]
    pub feedback: FloatParam,
    #[id = "mix"]
    pub mix: FloatParam,
}

impl Default for KoraVstParams {
    fn default() -> Self {
        Self {
            decay: FloatParam::new("Decay", 0.992, FloatRange::Linear { min: 0.9, max: 0.999 }),
            feedback: FloatParam::new("Feedback", 0.985, FloatRange::Linear { min: 0.9, max: 0.999 }),
            mix: FloatParam::new("Mix", 0.045, FloatRange::Linear { min: 0.01, max: 0.1 }),
        }
    }
}

impl ClapPlugin for KoraVst {
    const CLAP_ID: &'static str = "com.ryomodular.kora";
    const CLAP_DESCRIPTION: Option<&'static str> = Some("Kora Physical Modeling Synth");
    const CLAP_MANUAL_URL: Option<&'static str> = Some("https://ryomodular.com");
    const CLAP_SUPPORT_URL: Option<&'static str> = None;
    const CLAP_FEATURES: &'static [ClapFeature] = &[ClapFeature::Instrument, ClapFeature::Synth];
}

impl Vst3Plugin for KoraVst {
    const VST3_CLASS_ID: [u8; 16] = *b"RyomKoraSynth01";
    const VST3_SUBCATEGORIES: &'static [Vst3SubCategory] = &[Vst3SubCategory::Synth, Vst3SubCategory::Instrument];
}

impl Plugin for KoraVst {
    type BackgroundTask = ();
    type SysExMessage = ();

    fn new(_: &PluginContext<Self::BackgroundTask>, params: Arc<KoraVstParams>) -> Self {
        Self {
            params,
            synth: None,
        }
    }

    fn reset(&mut self) {
        self.synth = None;
    }

    fn initialize(&mut self, _audio_io_layout: &AudioIOLayout, buffer_config: &BufferConfig, _context: &mut impl InitContext<Self>) -> bool {
        self.synth = Some(KoraSynth::new(buffer_config.sample_rate));
        true
    }

    fn process(&mut self, buffer: &mut Buffer, _aux: &mut AuxiliaryBuffers, context: &mut impl ProcessContext<Self>) -> ProcessStatus {
        let mut synth = match &mut self.synth {
            Some(s) => s,
            None => return ProcessStatus::Normal,
        };

        // Simple MIDI note handling
        let mut next_event = context.next_event();
        for channel_samples in buffer.iter_samples() {
            // Process events (basic note on for demo)
            while let Some(event) = next_event {
                if let NoteEvent::NoteOn { note, velocity, .. } = event {
                    synth.pluck_closest(note, velocity * 127.0);
                }
                next_event = context.next_event();
            }

            let sample = synth.get_next_sample();
            for out in channel_samples {
                *out = sample;
            }
        }

        ProcessStatus::Normal
    }

    fn params(&self) -> Arc<dyn Params> {
        self.params.clone()
    }
}

nih_plug::nih_export_clap!(KoraVst);
nih_plug::nih_export_vst3!(KoraVst);
